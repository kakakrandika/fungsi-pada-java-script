function Penjumlahan(a,b){
	return a + b;
}
function Perkalian(a,b){
	return a * b;
}

var a = parseInt(prompt('Masukkan Nilai a'));
var b = parseInt(prompt('Masukkan Nilai b'));

var hasil1 = Penjumlahan(a,b);
var hasil2 = Perkalian(a,b);
alert('Hasilnya Penjumlahan nya adalah ' + hasil1);
alert('Hasilnya Perkalian nya adalah ' + hasil2);
